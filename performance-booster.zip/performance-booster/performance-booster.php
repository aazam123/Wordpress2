<?php
/*
Plugin Name: AlyxWeb Performance Booster
Description: Lightweight performance plugin (cache + optimizations).
Version: 5.6
Author: Alyxweb
Author URI: https://alyxweb.com/
*/

if (!defined('ABSPATH')) exit;

class PerformanceBooster {
    private $cache_dir;

    public function __construct() {
        $this->cache_dir = WP_CONTENT_DIR . '/cache/performance-booster/';
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('template_redirect', [$this, 'start_cache']);
        add_action('shutdown', [$this, 'end_cache']);
        add_action('admin_post_pb_clear_cache', [$this, 'clear_cache']);
        add_action('admin_bar_menu', [$this, 'add_admin_bar'], 100);
    }

    /* ---------------- CACHE ---------------- */
    public function start_cache() {
        if (is_user_logged_in() || is_admin()) return;
        ob_start([$this, 'process_output']);
    }

    public function end_cache() {
        if (is_user_logged_in() || is_admin()) return;
        if (!is_dir($this->cache_dir)) wp_mkdir_p($this->cache_dir);
        $key = md5($_SERVER['REQUEST_URI']);
        $html = ob_get_flush();
        if ($html) file_put_contents($this->cache_dir . $key . '.html', $html);
    }

    public function process_output($html) {
        $opts = get_option('performance_booster_options', []);

        if (!empty($opts['enable_html_minify'])) $html = $this->minify_html($html);
        if (!empty($opts['enable_css_minify']))  $html = $this->minify_css($html);
        if (!empty($opts['enable_js_minify']))   $html = $this->minify_js($html);
        if (!empty($opts['enable_lazyload']))    $html = $this->add_lazyload($html);

        return $html;
    }

    private function minify_html($html) {
        return preg_replace('/\s+/', ' ', $html);
    }

    private function minify_css($html) {
        return preg_replace_callback('#<style\b[^>]*>(.*?)</style>#is', function($m) {
            $min = preg_replace('/\s+/', ' ', $m[1]);
            $min = str_replace(['; ', ': '], [';', ':'], $min);
            return "<style>$min</style>";
        }, $html);
    }

    private function minify_js($html) {
        return preg_replace_callback('#<script\b[^>]*>(.*?)</script>#is', function($m) {
            $min = preg_replace('/\s+/', ' ', $m[1]);
            $min = str_replace(['; ', ' = '], [';', '='], $min);
            return "<script>$min</script>";
        }, $html);
    }

    private function add_lazyload($html) {
        // Swap img/iframe src → data-src
        $html = preg_replace('/<img(.*?)src=/', '<img$1data-src=', $html);
        $html = preg_replace('/<iframe(.*?)src=/', '<iframe$1data-src=', $html);

        // Add JS lazyloader
        $script = <<<EOT
<script>
document.addEventListener("DOMContentLoaded",function(){
  let els=[...document.querySelectorAll("img[data-src],iframe[data-src]")];
  let obs=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        let el=e.target;
        el.src=el.dataset.src;
        el.removeAttribute("data-src");
        obs.unobserve(el);
      }
    })
  });
  els.forEach(el=>obs.observe(el));
});
</script>
EOT;
        return str_replace('</body>', $script.'</body>', $html);
    }

    public function clear_cache() {
        if (is_dir($this->cache_dir)) {
            foreach (glob($this->cache_dir . '*.html') as $f) unlink($f);
        }
        wp_redirect(wp_get_referer());
        exit;
    }

    /* ---------------- ADMIN ---------------- */
    public function admin_menu() {
        add_options_page('Performance Booster', 'Performance Booster', 'manage_options', 'performance-booster', [$this, 'settings_page']);
    }

    public function add_admin_bar($wp_admin_bar) {
        $args = [
            'id' => 'pb_clear_cache',
            'title' => 'Clear Cache',
            'href' => wp_nonce_url(admin_url('admin-post.php?action=pb_clear_cache'), 'pb_clear_cache'),
        ];
        $wp_admin_bar->add_node($args);
    }

    public function settings_page() {
        $opts = get_option('performance_booster_options', []);
        ?>
        <div class="wrap">
            <h1>Performance Booster</h1>
            <h2 class="nav-tab-wrapper">
                <a href="#general" class="nav-tab nav-tab-active">General</a>
                <a href="#optimizations" class="nav-tab">Optimizations</a>
                <a href="#tips" class="nav-tab">Recommended Setup</a>
            </h2>

            <div id="general" class="tab-content" style="display:block;">
                <form method="post" action="options.php">
                    <?php settings_fields('performance_booster_group'); ?>
                    <p><button type="submit" class="button button-primary">Save Settings</button></p>
            </div>

            <div id="optimizations" class="tab-content" style="display:none;">
                <h2>Optimizations</h2>
                <label><input type="checkbox" name="performance_booster_options[enable_html_minify]" <?php checked(!empty($opts['enable_html_minify'])); ?>> Enable HTML Minify</label><br>
                <label><input type="checkbox" name="performance_booster_options[enable_css_minify]" <?php checked(!empty($opts['enable_css_minify'])); ?>> Enable CSS Minify</label><br>
                <label><input type="checkbox" name="performance_booster_options[enable_js_minify]" <?php checked(!empty($opts['enable_js_minify'])); ?>> Enable JS Minify</label><br>
                <label><input type="checkbox" name="performance_booster_options[enable_lazyload]" <?php checked(!empty($opts['enable_lazyload'])); ?>> Enable LazyLoad (Images & iframes)</label><br>
                <p><button type="submit" class="button button-primary">Save Settings</button></p>
                </form>
            </div>

            <div id="tips" class="tab-content" style="display:none;">
                <div class="card" style="padding:15px; max-width:600px;">
                    <h2>Recommended Setup</h2>
                    <p>✔ Enable HTML, CSS, and JS minify</p>
                    <p>✔ Enable LazyLoad for images</p>
                    <p>✔ Use a CDN for static files</p>
                    <p>✔ Optimize large images manually</p>
                </div>
            </div>
        </div>

        <script>
        document.querySelectorAll(".nav-tab").forEach(tab=>{
            tab.addEventListener("click",function(e){
                e.preventDefault();
                document.querySelectorAll(".nav-tab").forEach(t=>t.classList.remove("nav-tab-active"));
                this.classList.add("nav-tab-active");
                document.querySelectorAll(".tab-content").forEach(c=>c.style.display="none");
                document.querySelector(this.getAttribute("href")).style.display="block";
            });
        });
        </script>
        <?php
    }
}

new PerformanceBooster();

add_action('admin_init', function() {
    register_setting('performance_booster_group', 'performance_booster_options');
});

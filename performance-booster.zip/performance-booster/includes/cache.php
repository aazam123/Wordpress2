<?php
if (!defined('ABSPATH')) exit;

// Basic filesystem cache
add_action('template_redirect', function() {
    if (!get_option('pb_enable_cache')) return;

    if (!is_user_logged_in() && !is_admin()) {
        $cache_key = md5($_SERVER['REQUEST_URI']);
        $cache_file = WP_CONTENT_DIR . '/cache/pb-' . $cache_key . '.html';

        if (file_exists($cache_file)) {
            readfile($cache_file);
            exit;
        }

        ob_start(function($buffer) use ($cache_file) {
            file_put_contents($cache_file, $buffer);
            return $buffer;
        });
    }
});

<?php
if (!defined('ABSPATH')) exit;

// Add settings menu
add_action('admin_menu', function() {
    add_menu_page(
        'Performance Booster',
        'Performance Booster',
        'manage_options',
        'performance-booster',
        'pb_render_admin_page',
        'dashicons-performance',
        80
    );
});

// Render settings page
function pb_render_admin_page() {
    ?>
    <div class="wrap">
        <h1>Performance Booster</h1>

        <!-- Recommended Setup Card -->
        <div id="pb-recommended-card" class="pb-card">
            <div class="pb-card-header" onclick="pbToggleCard()">
                <h2>⚡ Recommended Setup</h2>
                <button id="pb-toggle-btn" class="button">Hide</button>
            </div>
            <div id="pb-card-body" class="pb-card-body">
                <ul>
                    <li>✅ Enable Page Caching</li>
                    <li>✅ Minify HTML, CSS, and JS</li>
                    <li>✅ Use Lazy Loading for images</li>
                    <li>✅ Serve images in WebP format</li>
                    <li>✅ Connect to a CDN</li>
                </ul>
            </div>
        </div>

        <!-- Tabs -->
        <h2 class="nav-tab-wrapper">
            <a href="#general" class="nav-tab nav-tab-active" onclick="pbSwitchTab(event,'general')">General</a>
            <a href="#advanced" class="nav-tab" onclick="pbSwitchTab(event,'advanced')">Advanced</a>
        </h2>

        <div id="general" class="pb-tab-content" style="display:block;">
            <form method="post" action="options.php">
                <?php
                    settings_fields('pb_settings_group');
                    do_settings_sections('performance-booster');
                    submit_button();
                ?>
            </form>
        </div>

        <div id="advanced" class="pb-tab-content" style="display:none;">
            <p>Advanced optimization options will go here.</p>
        </div>
    </div>

    <style>
        .pb-card {
            border:1px solid #ccc;
            border-radius:8px;
            padding:15px;
            margin-bottom:20px;
            background:#fff;
            box-shadow:0 2px 5px rgba(0,0,0,0.05);
        }
        .pb-card-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            cursor:pointer;
        }
        .pb-card-body {
            margin-top:10px;
        }
    </style>

    <script>
        function pbSwitchTab(evt, tabId) {
            document.querySelectorAll('.pb-tab-content').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('nav-tab-active'));
            document.getElementById(tabId).style.display = 'block';
            evt.currentTarget.classList.add('nav-tab-active');
        }

        function pbToggleCard() {
            let body = document.getElementById("pb-card-body");
            let btn = document.getElementById("pb-toggle-btn");

            if(body.style.display === "none") {
                body.style.display = "block";
                btn.innerText = "Hide";
                localStorage.setItem("pbCardCollapsed", "false");
            } else {
                body.style.display = "none";
                btn.innerText = "Show";
                localStorage.setItem("pbCardCollapsed", "true");
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            let collapsed = localStorage.getItem("pbCardCollapsed");
            let body = document.getElementById("pb-card-body");
            let btn = document.getElementById("pb-toggle-btn");

            if(collapsed === "true") {
                body.style.display = "none";
                btn.innerText = "Show";
            }
        });
    </script>
    <?php
}

// Register settings
add_action('admin_init', function() {
    register_setting('pb_settings_group', 'pb_enable_cache');
    register_setting('pb_settings_group', 'pb_minify_html');
    register_setting('pb_settings_group', 'pb_minify_css');
    register_setting('pb_settings_group', 'pb_minify_js');
    register_setting('pb_settings_group', 'pb_lazy_load');

    add_settings_section('pb_main_section', 'General Settings', null, 'performance-booster');

    add_settings_field('pb_enable_cache', 'Enable Page Cache', function() {
        $val = get_option('pb_enable_cache', 0);
        echo '<input type="checkbox" name="pb_enable_cache" value="1" ' . checked(1, $val, false) . '> Store cached pages on filesystem';
    }, 'performance-booster', 'pb_main_section');

    add_settings_field('pb_minify_html', 'Minify HTML', function() {
        $val = get_option('pb_minify_html', 0);
        echo '<input type="checkbox" name="pb_minify_html" value="1" ' . checked(1, $val, false) . '> Compress HTML output';
    }, 'performance-booster', 'pb_main_section');

    add_settings_field('pb_minify_css', 'Minify CSS', function() {
        $val = get_option('pb_minify_css', 0);
        echo '<input type="checkbox" name="pb_minify_css" value="1" ' . checked(1, $val, false) . '> Compress CSS files';
    }, 'performance-booster', 'pb_main_section');

    add_settings_field('pb_minify_js', 'Minify JS', function() {
        $val = get_option('pb_minify_js', 0);
        echo '<input type="checkbox" name="pb_minify_js" value="1" ' . checked(1, $val, false) . '> Compress JavaScript files';
    }, 'performance-booster', 'pb_main_section');

    add_settings_field('pb_lazy_load', 'Lazy Load Images', function() {
        $val = get_option('pb_lazy_load', 0);
        echo '<input type="checkbox" name="pb_lazy_load" value="1" ' . checked(1, $val, false) . '> Defer image loading until visible';
    }, 'performance-booster', 'pb_main_section');
});
